# SuperStore Operations Data Analysis Dashboard

This dashboard analyzes SuperStore's operations and increase its profitability to avoid bankruptcy.

## View the Dashboard
https://public.tableau.com/views/Byron_Saldana_Data_Visualization_Project/SuperstoreOpsAnalysis?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link

## Key Insights
- Profits and Losses Analysis
- Advertising Analysis
- Return Items Analysis


